# Digital Business Card - Amine Saadani

A modern, interactive, and visually stunning digital business card built with React, TypeScript, and Tailwind CSS. This project is designed to be a memorable and effective way to share contact information.

![Digital Business Card Screenshot](/assets/profile-image.jpg)
*(Note: This is a static image. See the live version for interactive effects.)*

---

## ✨ Features

-   **Interactive 3D Tilt:** The card subtly tilts based on mouse movement, creating an engaging 3D effect.
-   **Animated Aurora Border:** A beautiful, slowly rotating gradient border gives the card a premium, high-tech feel.
-   **Cursor Spotlight:** A "molten" spotlight effect follows the cursor, illuminating the background.
-   **Dynamic Animations:** Elements fade and slide in gracefully on load for a smooth user experience.
-   **One-Click Contact Save:** Download contact details directly to your address book with a generated `.vcf` file.
-   **Responsive Design:** Looks great on all devices, from desktops to mobile phones.
-   **Accessible:** ARIA labels and semantic HTML for better accessibility.

## 🚀 Tech Stack

-   **Frontend:** [React](https://react.dev/)
-   **Language:** [TypeScript](https://www.typescriptlang.org/)
-   **Styling:** [Tailwind CSS](https://tailwindcss.com/)
-   **Buildless Setup:** Runs directly in the browser using ES Modules via [esm.sh](https://esm.sh/).

## 🛠️ Setup and Running Locally

This project is set up to run without a complex build process.

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/digital-business-card.git
    cd digital-business-card
    ```

2.  **Add Assets:**
    -   Create an `assets/` directory in the project root.
    -   Place your profile picture inside the `assets/` directory and name it `profile-image.jpg`.
    -   (Optional) Add a favicon named `favicon.ico` to the `assets/` directory.

3.  **Serve the files:**
    You need a local server to handle the requests correctly. You can use any simple static server.

    If you have Python installed:
    ```bash
    # For Python 3
    python -m http.server
    ```

    If you have Node.js and `serve` installed (`npm install -g serve`):
    ```bash
    serve .
    ```

4.  **Open in browser:**
    Navigate to `http://localhost:8000` (or the port specified by your server) in your web browser.

## 📄 License

This project is licensed under the MIT License.
