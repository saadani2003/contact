
import React, { useState, useEffect, useRef, MouseEventHandler } from 'react';
import { CONTACT_INFO, ICONS } from './constants';
import ContactButton from './components/ContactButton';
import VCardButton from './components/VCardButton';

const App: React.FC = () => {
  const { name, profileImageUrl, phone, email, linkedIn } = CONTACT_INFO;
  const cardRef = useRef<HTMLDivElement>(null);
  const mainRef = useRef<HTMLElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Background spotlight effect
  useEffect(() => {
    const mainElement = mainRef.current;
    if (!mainElement) return;

    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      mainElement.style.setProperty('--mouse-x', `${clientX}px`);
      mainElement.style.setProperty('--mouse-y', `${clientY}px`);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  // Card 3D tilt effect
  const handleMouseMove: MouseEventHandler<HTMLDivElement> = (e) => {
    const card = cardRef.current;
    if (!card) return;

    const { left, top, width, height } = card.getBoundingClientRect();
    const x = e.clientX - left;
    const y = e.clientY - top;

    const rotateX = -1 * ((y - height / 2) / (height / 2)) * 8; // Max rotation 8deg
    const rotateY = ((x - width / 2) / (width / 2)) * 8;

    card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (card) {
      card.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg)`;
    }
  };
  
  // Staggered load animation
  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);


  return (
    <main 
      ref={mainRef}
      className="spotlight-bg bg-slate-950 min-h-screen w-full flex items-center justify-center p-4 selection:bg-[#ba4b2f]/20"
    >
      <div 
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        style={{ transition: 'transform 0.1s ease', transform: 'perspective(1000px)' }}
        className={`animated-border relative w-full max-w-sm mx-auto rounded-2xl shadow-2xl shadow-black/40 transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
      >
        <div className="w-full h-full overflow-hidden rounded-2xl bg-slate-900/80 backdrop-blur-xl">
          <div className="relative p-8 flex flex-col items-center text-center text-white" style={{ transform: 'translateZ(40px)', transformStyle: 'preserve-3d' }}>
            <div 
              className={`mb-4 transition-all duration-500 ease-out ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
            >
              <img
                src={profileImageUrl}
                alt={name}
                className="w-28 h-28 rounded-full object-cover border-4 border-white/20 shadow-lg"
              />
            </div>
            <h1 
              className={`text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-br from-white to-[#f0a590] transition-all duration-500 ease-out delay-100 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
            >
              {name}
            </h1>

            <div 
              className={`w-full mt-8 space-y-3 transition-all duration-500 ease-out delay-300 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
            >
              <ContactButton
                href={`tel:${phone.replace(/\s/g, '')}`}
                icon={ICONS.phone}
                text={phone}
                label="Call Amine"
              />
              <ContactButton
                href={`mailto:${email}`}
                icon={ICONS.email}
                text={email}
                label="Email Amine"
              />
              <ContactButton
                href={linkedIn}
                icon={ICONS.linkedIn}
                text="LinkedIn Profile"
                label="View LinkedIn Profile"
                isExternal={true}
              />
              <VCardButton contactInfo={CONTACT_INFO} />
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default App;