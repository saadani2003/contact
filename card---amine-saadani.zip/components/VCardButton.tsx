import React from 'react';
import type { ContactInfo } from '../types';
import { ICONS } from '../constants';

interface VCardButtonProps {
  contactInfo: ContactInfo;
}

const VCardButton: React.FC<VCardButtonProps> = ({ contactInfo }) => {
  const handleSaveContact = () => {
    const { name, phone, email, linkedIn } = contactInfo;

    const vCardString = [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `FN:${name}`,
      `TEL;TYPE=CELL:${phone.replace(/\s/g, '')}`,
      `EMAIL:${email}`,
      `URL;TYPE=LinkedIn:${linkedIn}`,
      'END:VCARD'
    ].join('\n');

    const blob = new Blob([vCardString], { type: 'text/vcard;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `${name.replace(/\s/g, '_')}.vcf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <button
      onClick={handleSaveContact}
      aria-label="Save contact to address book"
      className="w-full flex items-center justify-center p-3 bg-gradient-to-r from-[#ba4b2f] to-[#9e3f26] bg-[length:200%_auto] text-white font-bold rounded-lg transition-all duration-500 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-[#ba4b2f] focus:ring-opacity-75 hover:shadow-lg hover:shadow-[#ba4b2f]/50 hover:bg-[position:right_center]"
    >
      <span className="mr-2">{ICONS.download}</span>
      Save Contact
    </button>
  );
};

export default VCardButton;