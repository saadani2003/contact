
export interface ContactInfo {
  name: string;
  profileImageUrl: string;
  phone: string;
  email: string;
  linkedIn: string;
}